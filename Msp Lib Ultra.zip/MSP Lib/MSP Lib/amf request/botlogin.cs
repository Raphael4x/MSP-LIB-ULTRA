﻿using System;
using System.IO;
using System.Net;
using fyt.MSPlib.Authorization;
using fyt.MSPlib.Class;

namespace msplib.bots;

internal class Botlogin
{
    public static (string Ticket, int ActorID, string NebulaId, string NebulaToken, bool Success, string username, string password) LoginForBots(string Username, string Password, string Proxy = null)
    {
        dynamic val = amf.SendAMF("MovieStarPlanet.WebService.User.AMFUserServiceWeb.Login", new object[6] { Username, Password, null, null, null, "MSP1-Standalone:XXXXXX" }, Proxy);
        dynamic val2 = val == null || val.ToString().Contains("ERROR") || !((val["loginStatus"]["status"] == "Success" || val["loginStatus"]["status"] == "ThirdPartyCreated") ? true : false) || 1 == 0 || false || false;
        if ((!(val2 ? true : false) || 1 == 0) && (!((val2 | false) ? true : false) || 1 == 0))
        {
            int item = (int)val["loginStatus"]["actor"]["ActorId"];
            string item2 = (string)val["loginStatus"]["ticket"];
            string item3 = (string)val["loginStatus"]["nebulaLoginStatus"]["profileId"];
            string item4 = (string)val["loginStatus"]["nebulaLoginStatus"]["accessToken"];
            return (item2, item, item3, item4, true, Username, Password);
        }
        if (((string)val["loginStatus"]["status"]).ToUpper() == "ERROR")
        {
            Utils.CLManiac("You are rate limited, please change your ip and after click on any key on your keyboard!\n");
            Console.ReadKey();
            return LoginForBots(Username, Password);
        }
        return (null, 0, null, null, false, Username, Password);
    }

    public static (string Ticket, int ActorID, string NebulaId, string NebulaToken, bool Success, string username, string password) LoginForBotsAuto(string Username, string Password, string Proxy = null)
    {
        dynamic val = amf.SendAMF("MovieStarPlanet.WebService.User.AMFUserServiceWeb.Login", new object[6] { Username, Password, null, null, null, "MSP1-Standalone:XXXXXX" }, Proxy);
        dynamic val2 = val == null || val.ToString().Contains("ERROR") || !((val["loginStatus"]["status"] == "Success" || val["loginStatus"]["status"] == "ThirdPartyCreated") ? true : false) || 1 == 0 || false || false;
        if ((!(val2 ? true : false) || 1 == 0) && (!((val2 | false) ? true : false) || 1 == 0))
        {
            int item = (int)val["loginStatus"]["actor"]["ActorId"];
            string item2 = (string)val["loginStatus"]["ticket"];
            string item3 = (string)val["loginStatus"]["nebulaLoginStatus"]["profileId"];
            string item4 = (string)val["loginStatus"]["nebulaLoginStatus"]["accessToken"];
            return (item2, item, item3, item4, true, Username, Password);
        }
        if (((string)val["loginStatus"]["status"]).ToUpper() == "ERROR")
        {
            Utils.CLManiac("You are rate limited, please change your ip and after click on any key on your keyboard!\n");
            return LoginForBotsAuto(Username, Password);
        }
        return (null, 0, null, null, false, Username, Password);
    }

    public static (string Ticket, int ActorID, string NebulaId, string NebulaToken, bool Success, string username, string password) LoginForBotsET(string Username, string Password, string Proxy = null)
    {
        dynamic val = amf.SendAMF("MovieStarPlanet.WebService.User.AMFUserServiceWeb.Login", new object[6] { Username, Password, null, null, null, "MSP1-Standalone:XXXXXX" }, Proxy);
        dynamic val2 = val == null || val.ToString().Contains("ERROR") || !((val["loginStatus"]["status"] == "Success" || val["loginStatus"]["status"] == "ThirdPartyCreated") ? true : false) || 1 == 0 || false || false;
        if ((!(val2 ? true : false) || 1 == 0) && (!((val2 | false) ? true : false) || 1 == 0))
        {
            int item = (int)val["loginStatus"]["actor"]["ActorId"];
            string text = (string)val["loginStatus"]["ticket"];
            string text2 = (string)val["loginStatus"]["nebulaLoginStatus"]["profileId"];
            string text3 = (string)val["loginStatus"]["nebulaLoginStatus"]["accessToken"];
            try
            {
                File.AppendAllText("Tickets-" + Var.server + ".txt", text + "•" + item + "•" + text2 + "•" + text3 + "•" + Username + "•" + Password + "\n");
            }
            catch (Exception)
            {
            }
            return (text, item, text2, text3, true, Username, Password);
        }
        if (((string)val["loginStatus"]["status"]).ToUpper() == "ERROR")
        {
            Utils.CLManiac("You are rate limited, please change your ip and after click on any key on your keyboard!\n");
            return LoginForBotsET(Username, Password);
        }
        return (null, 0, null, null, false, Username, Password);
    }
}