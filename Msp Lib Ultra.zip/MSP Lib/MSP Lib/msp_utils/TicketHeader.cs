namespace fyt.MSPlib.Class;

internal class TicketHeader
{
	public string Ticket { get; set; }

	public object[] anyAttribute { get; set; }
}
