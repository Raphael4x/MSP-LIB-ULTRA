using System;
using System.Linq;
using System.Text;

namespace fyt.MSPlib.Authorization;

internal class Utils
{
	private static Random random = new Random();

	public static string GenerateID()
	{
		string text = "";
		do
		{
			text += random.Next(0, int.MaxValue).ToString("X");
		}
		while (text.Length < 48);
		text = text.Substring(0, 46);
		return Convert.ToBase64String(Encoding.Default.GetBytes(text));
	}

	public static string RandomString(int length)
	{
		return new string((from s in Enumerable.Repeat("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789", length)
			select s[random.Next(s.Length)]).ToArray());
	}
}
