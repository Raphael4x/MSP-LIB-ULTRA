using System;
using System.IO;
using System.Net;
using System.Text;
using System.Threading;
using System.Xml.Serialization;
using FluorineFx.IO;
using fyt.MSPlib.Authorization;

namespace msplib.MovieStarPlanet;

internal class Request
{
    public static object SendAmfPacketToMspApi(string Method, object[] Arguments, string Proxy = null)
    {
        Random random = new Random();
        string value = random.Next(0, 213) + "." + random.Next(0, 146) + "." + random.Next(0, 50) + "." + random.Next(0, 30);

        AMFMessage aMFMessage = new AMFMessage(3);
        aMFMessage.AddHeader(new AMFHeader("sessionID", mustUnderstand: false, Utils.RandomString(24)));
        aMFMessage.AddHeader(new AMFHeader("id", mustUnderstand: false, ChecksumCalculator.createChecksum(Arguments)));
        aMFMessage.AddHeader(new AMFHeader("needClassName", mustUnderstand: false, false));
        aMFMessage.AddBody(new AMFBody(Method, "/1", Arguments));

        using (MemoryStream memoryStream = new MemoryStream())
        {
            using (AMFSerializer aMFSerializer = new AMFSerializer(memoryStream))
            {
                aMFSerializer.WriteMessage(aMFMessage);
                aMFSerializer.Flush();
            }

            HttpWebRequest httpWebRequest = (HttpWebRequest)WebRequest.Create("https://ws-" + Login_form.GetServer.ToLower() + ".mspapis.com/Gateway.aspx?method=" + Method);
            httpWebRequest.Headers.Add("X-forwarded-for", value);
            httpWebRequest.Referer = "app:/cache/t1.bin/[[DYNAMIC]]/2";
            httpWebRequest.Accept = "text/xml, application/xml, application/xhtml+xml, text/html;q=0.9, text/plain;q=0.8, text/css, image/png, image/jpeg, image/gif;q=0.8, application/x-shockwave-flash, video/mp4;q=0.9, flv-application/octet-stream;q=0.8, video/x-flv;q=0.7, audio/mp4, application/futuresplash, */*;q=0.5, application/x-mpegURL";
            httpWebRequest.ContentType = "application/x-amf";
            httpWebRequest.UserAgent = "Mozilla/5.0 (Windows; U; en) AppleWebKit/533.19.4 (KHTML, like Gecko) AdobeAIR/32.0";
            httpWebRequest.Headers["X-Flash-Version"] = "32,0,0,100";
            httpWebRequest.Method = "POST";

            if (Proxy != null)
            {
                httpWebRequest.Proxy = new WebProxy(Proxy);
            }

            byte[] bytes = memoryStream.ToArray();

            try
            {
                using (Stream requestStream = httpWebRequest.GetRequestStream())
                {
                    requestStream.Write(bytes, 0, bytes.Length);
                }

                using (HttpWebResponse httpWebResponse = (HttpWebResponse)httpWebRequest.GetResponse())
                {
                    using (MemoryStream responseStream = new MemoryStream())
                    {
                        httpWebResponse.GetResponseStream().CopyTo(responseStream);
                        object result = DecodeResponse(responseStream.ToArray());
                        return result;
                    }
                }
            }
            catch (Exception ex)
            {
                return "ERROR! " + ex.ToString();
            }
        }
    }

    public static dynamic DecodeResponse(byte[] Body)
	{
		MemoryStream memoryStream = new MemoryStream(Body);
		AMFDeserializer aMFDeserializer = new AMFDeserializer(memoryStream);
		AMFMessage aMFMessage = aMFDeserializer.ReadAMFMessage();
		object content = aMFMessage.Bodies[0].Content;
		memoryStream.Dispose();
		aMFDeserializer.Dispose();
		return content;
	}
}
